/*
 * Assignment2.h
 *
 *  Created on: Feb 12, 2020
 *      Author: joseph
 */

#ifndef ASSIGNMENT2_H_
#define ASSIGNMENT2_H_

class Assignment2 {
public:
	Assignment2();
	virtual ~Assignment2();
};

#endif /* ASSIGNMENT2_H_ */
